package uk.ac.nott.cs.g53dia.agent;

public enum CellType {
	PUMP, STATION, WELL
}
