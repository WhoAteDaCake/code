#include "Shapes.h"

unsigned int Square::ID = 0;