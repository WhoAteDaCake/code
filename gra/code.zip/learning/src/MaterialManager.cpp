#include "MaterialManager.h"

unsigned int MaterialManager::ID = 0;