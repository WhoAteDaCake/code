#pragma once

#ifndef LIBS_H
#define LIBS_H

#include <iostream>
#include <fstream>
#include <cstdio>
#include "SOIL.h"

#include "Mesh.h"
#include "Shapes.h"
#include "Engine.h"

#endif // DEBUG

// #ifndef TINY_LOADER_H
// #define TINY_LOADER_H

// #endif // !1TINY_LOADER_H
