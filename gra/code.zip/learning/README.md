# Freglut

install freglut `sudo apt-get install freeglut3-dev`